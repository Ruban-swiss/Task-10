"""
1. Open command prompt.

2. Navigate to my Python project path
C:\Python\PIP
3. Run the following command to generate the requirements.txt file
    pip freeze > requirements.txt
4. the requirements.txt file has been created in my corresponding folder

5. I could also install the same dependencies by running:

pip install -r requirements.txt



"""
